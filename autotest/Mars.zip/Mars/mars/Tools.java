package mars;

import mars.mips.hardware.AddressErrorException;
import mars.mips.hardware.RegisterFile;
import mars.mips.instructions.InstructionSet;
import mars.mips.instructions.LoadedInstruction;


public class Tools {

   public static int getGPR(int num) {
      return RegisterFile.getValue(num);
   }

   public static void setGPR(int num, int val) {
      RegisterFile.updateRegister(num, val);
   }

   public static int getPC() {
      return RegisterFile.getProgramCounter();
   }

   public static int loadB(int address) {
      try {
         return Globals.memory.getByte(address);
      } catch (AddressErrorException e) {
         System.err.printf("loadB() : Address Error: %#x%n", address);
         return -1;
      }
   }

   public static int loadH(int address) {
      try {
         return Globals.memory.getHalf(address);
      } catch (AddressErrorException e) {
         System.err.printf("loadH() : Address Error: %#x%n", address);
         return -1;
      }
   }

   public static int loadW(int address) {
      try {
         return Globals.memory.getWord(address);
      } catch (AddressErrorException e) {
         System.err.printf("loadW() : Address Error: %#x%n", address);
         return -1;
      }
   }

   public static int storeB(int address, int val) {
      try {
         return Globals.memory.setByte(address, val);
      } catch (AddressErrorException e) {
         System.err.printf("storeB() : Address Error: %#x%n", address);
         return -1;
      }
   }

   public static int storeH(int address, int val) {
      try {
         return Globals.memory.setHalf(address, val);
      } catch (AddressErrorException e) {
         System.err.printf("storeH() : Address Error: %#x%n", address);
         return -1;
      }
   }

   public static int storeW(int address, int val) {
      try {
         return Globals.memory.setWord(address, val);
      } catch (AddressErrorException e) {
         System.err.printf("storeW() : Address Error: %#x%n", address);
         return -1;
      }
   }

   public static void branch(int offset) {
      InstructionSet.processBranch(offset);
   }

   public static void jump(int address) {
      InstructionSet.processJump(address);
   }

   public static void registerInstruction(LoadedInstruction instruction) {
      Globals.instructionSet.registerInstruction(instruction);
      Globals.instructionSet.generateMatchMaps();
   }

//   public static void registerInstruction(String template, String formatStr, String encoding, SimulationCode code) {
//      BasicInstructionFormat format = null;
//      switch (formatStr) {
//         case "I_BRANCH":
//            format = BasicInstructionFormat.I_BRANCH_FORMAT;
//            break;
//         case "I":
//            format = BasicInstructionFormat.I_FORMAT;
//            break;
//         case "J":
//            format = BasicInstructionFormat.J_FORMAT;
//            break;
//         case "R":
//            format = BasicInstructionFormat.R_FORMAT;
//      }
//      Globals.instructionSet.registerInstruction(template, format, encoding, code);
//   }
}
