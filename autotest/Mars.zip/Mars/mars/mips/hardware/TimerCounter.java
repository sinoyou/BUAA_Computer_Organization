package mars.mips.hardware;

import mars.Globals;
import mars.simulator.Exceptions;
import mars.simulator.Simulator;

import java.util.Observable;
import java.util.Observer;

public class TimerCounter implements Observer {
   int ID;

   // Current state
   private enum State {
      IDLE, LOAD, CNT, INT;
   }
   private State state;

   private class recordingRegister extends Register {
      recordingRegister(String n, int num, int val) {
         super(n, num, val);
      }

      @Override
      public synchronized int setValue(int val) {
         int old = value;
         if(Globals.getSettings().getBackSteppingEnabled())
            Globals.program.getBackStepper().addMemoryRestoreWord(indexToAddress(number), old);
         value = val;
         notifyAnyObservers(AccessNotice.WRITE);
         return old;
      }
   }

   // This is the three registers
   private recordingRegister ctrl   = new recordingRegister("ctrl", 0, 0);
   private recordingRegister preset = new recordingRegister("preset", 1, 0);
   private recordingRegister count  = new recordingRegister("count", 2, 0);

   private recordingRegister[] registers = {ctrl, preset, count};

   private Register interrupt = new Register("interrupt", 0, 0);

   // A flag to see if there is an instruction which modifies the value of the registers.
   private Boolean isAccessed;

   public TimerCounter(int ID) {
      this.ID = ID;
      try {
         Globals.memory.addObserver(this, Memory.timerCounterLowAddress[ID], Memory.timerCounterHighAddress[ID]);
         ctrl.addObserver(this);
         interrupt.addObserver(this);
      } catch (AddressErrorException ignored) {}
      reset();
   }

   public void reset() {
      state = State.IDLE;
      for(recordingRegister register : registers) {
         register.resetValue();
      }
      interrupt.resetValue();
      this.isAccessed = false;
   }

   void setRegister(int address, int value) {
      int offset = address / 4;
      registers[offset].setValue(value);
   }

   int getRegister(int address) {
      int offset = address / 4;
      return registers[offset].getValue();
   }

   public void update(Observable o, Object arg) {
      if (!Globals.getSettings().getTimerCounterEnabled()) {
         return;
      }
      AccessNotice notice = (AccessNotice) arg;
      if (notice instanceof MemoryAccessNotice) {
         isAccessed = true;
      } else if (notice instanceof RegisterAccessNotice && notice.getAccessType() == AccessNotice.WRITE) {
         if(interrupt.getValue() != 0 && (ctrl.getValue() & 8) != 0)
            Simulator.externalInterruptingDevice = Exceptions.EXTERNAL_INTERRUPT_TC0;
         else if(Simulator.externalInterruptingDevice == Exceptions.EXTERNAL_INTERRUPT_TC0)
            Simulator.externalInterruptingDevice = 0;
      }
   }

   public void updateState() {
      if(!Globals.getSettings().getTimerCounterEnabled()) {
         return;
      }
      if(isAccessed) {
         isAccessed = false;
         return;
      }
      switch (state) {
         case IDLE:
            if((ctrl.getValue() & 1) != 0) {
               state = State.LOAD;
               interrupt.setValue(0);
            }
            break;
         case LOAD:
            count.setValue(preset.getValue());
            state = State.CNT;
            break;
         case CNT:
            if((ctrl.getValue() & 1) != 0) {
               count.setValue(count.getValue()-1);
               if(count.getValue() == 0) {
                  state = State.INT;
                  interrupt.setValue(1);
               }
            } else {
               state = State.IDLE;
            }
            break;
         case INT:
            if((ctrl.getValue() & 6) == 0) {
               ctrl.setValue(ctrl.getValue() & (~1));
            } else {
               interrupt.setValue(0);
               state = State.IDLE;
            }
            state = State.IDLE;
            break;
      }
   }

   int indexToAddress(int index) {
      return Memory.timerCounterLowAddress[ID] + index * 4;
   }
}
