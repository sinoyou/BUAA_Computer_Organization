package mars.mips.instructions;

import mars.ProcessingException;
import mars.ProgramStatement;

public interface LoadedInstruction extends SimulationCode {

   public String getTemplate();

   public String getFormatStr();

   public String getEncoding();
}
